# IKT-projekt
 
## Képek és ikonok forrása

- Pexels:https://www.pexels.com/hu-hu/
- Pixabay:https://pixabay.com/hu/
- Picsum:https://picsum.photos/
- Freepik:https://www.freepik.com/
- Flaticon:https://www.flaticon.com/
:camel: